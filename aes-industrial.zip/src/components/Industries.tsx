'use client';

import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';

const industries = [
  { id: '01', name: 'STEEL', fullName: 'Steel Industry', description: 'Heavy machinery & maintenance for steel plants' },
  { id: '02', name: 'POWER', fullName: 'Power Sector', description: 'Equipment for power generation facilities' },
  { id: '03', name: 'MINING', fullName: 'Mining Operations', description: 'Rugged solutions for mining environments' },
  { id: '04', name: 'OIL & GAS', fullName: 'Oil & Gas', description: 'Safety-certified petroleum industry tools' },
  { id: '05', name: 'INFRA', fullName: 'Infrastructure', description: 'Construction & development equipment' },
  { id: '06', name: 'AUTO', fullName: 'Automotive', description: 'Precision tools for manufacturing' },
  { id: '07', name: 'ENGG', fullName: 'Engineering', description: 'Solutions for fabrication works' },
];

export default function Industries() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="industries" className="relative py-32 bg-[#0d0d0d] overflow-hidden">
      {/* Diagonal stripes background */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute inset-0" style={{
          backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 35px, white 35px, white 36px)',
        }} />
      </div>

      <div className="container mx-auto px-4 relative z-10" ref={ref}>
        {/* Section header */}
        <div className="flex items-center gap-4 mb-16">
          <div className="text-[#d35400] font-mono text-sm tracking-widest">03</div>
          <div className="h-px flex-1 bg-gray-800" />
          <div className="text-gray-600 font-mono text-sm tracking-widest">INDUSTRIES</div>
        </div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="mb-16"
        >
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-black text-white leading-tight">
            POWERING INDIA&apos;S
            <br />
            <span className="text-[#d35400]">HEAVY INDUSTRIES</span>
          </h2>
        </motion.div>

        {/* Industries list - Horizontal scroll on mobile, grid on desktop */}
        <div className="relative">
          {/* Desktop grid */}
          <div className="hidden lg:grid lg:grid-cols-7 gap-1">
            {industries.map((industry, index) => (
              <motion.div
                key={industry.id}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.1 * index }}
                className="group relative bg-black border border-gray-800 hover:border-[#d35400] transition-all duration-500 aspect-[3/4] overflow-hidden"
              >
                {/* Number */}
                <div className="absolute top-4 left-4 text-[#d35400] font-mono text-xs">
                  {industry.id}
                </div>

                {/* Content */}
                <div className="absolute inset-0 flex flex-col justify-end p-4">
                  {/* Short name - visible by default */}
                  <div className="text-2xl font-black text-white tracking-tight group-hover:opacity-0 transition-opacity duration-300">
                    {industry.name}
                  </div>

                  {/* Full info - visible on hover */}
                  <div className="absolute inset-0 flex flex-col justify-end p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-t from-[#d35400]/90 to-transparent">
                    <div className="text-lg font-bold text-white mb-1">{industry.fullName}</div>
                    <div className="text-white/80 text-xs leading-relaxed">{industry.description}</div>
                  </div>
                </div>

                {/* Hover accent line */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#d35400] transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
              </motion.div>
            ))}
          </div>

          {/* Mobile horizontal scroll */}
          <div className="lg:hidden overflow-x-auto pb-4 -mx-4 px-4">
            <div className="flex gap-4" style={{ width: 'max-content' }}>
              {industries.map((industry, index) => (
                <motion.div
                  key={industry.id}
                  initial={{ opacity: 0, x: 30 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.1 * index }}
                  className="relative bg-black border border-gray-800 p-6 w-48 shrink-0"
                >
                  <div className="text-[#d35400] font-mono text-xs mb-3">{industry.id}</div>
                  <div className="text-xl font-black text-white mb-2">{industry.name}</div>
                  <div className="text-gray-500 text-xs">{industry.fullName}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8 }}
          className="mt-16 pt-16 border-t border-gray-800"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: '7+', label: 'Industries Served' },
              { value: '500+', label: 'Completed Projects' },
              { value: '100%', label: 'Quality Commitment' },
              { value: '24/7', label: 'Technical Support' },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.9 + index * 0.1 }}
              >
                <div className="text-4xl md:text-5xl font-black text-white mb-2">
                  {stat.value.includes('+') ? (
                    <>
                      {stat.value.replace('+', '')}
                      <span className="text-[#d35400]">+</span>
                    </>
                  ) : stat.value.includes('%') ? (
                    <>
                      {stat.value.replace('%', '')}
                      <span className="text-[#d35400]">%</span>
                    </>
                  ) : (
                    stat.value
                  )}
                </div>
                <div className="text-gray-600 text-xs tracking-widest font-mono uppercase">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
